import pygame
import struct
from config import BG_COLOR

# ─────────────────────────────────────────────────────────────
#  FRAMEBUFFER  (matriz 2D de tuplas RGB)
# ─────────────────────────────────────────────────────────────
class Framebuffer:
    def __init__(self, width: int, height: int, bg: tuple = BG_COLOR):
        self.width  = width
        self.height = height
        self.bg     = bg
        # armazena pixels como inteiros 0xRRGGBB para eficiência
        self._buf = [bg[0] << 16 | bg[1] << 8 | bg[2]] * (width * height)
        # Surface pygame para blitting eficiente
        self.surface = pygame.Surface((width, height))
        self._dirty  = True  # precisa re-renderizar?

    # ── acesso primitivo ──────────────────────────────────────
    def put_pixel(self, x: int, y: int, color: tuple):
        """Escreve um pixel no framebuffer (bounds-check incluído)."""
        if 0 <= x < self.width and 0 <= y < self.height:
            self._buf[y * self.width + x] = color[0] << 16 | color[1] << 8 | color[2]
            self._dirty = True

    def get_pixel(self, x: int, y: int) -> tuple:
        """Lê um pixel do framebuffer. Retorna (0,0,0) fora dos limites."""
        if 0 <= x < self.width and 0 <= y < self.height:
            v = self._buf[y * self.width + x]
            return ((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF)
        return (0, 0, 0)

    def clear(self, color: tuple = None):
        c = color or self.bg
        v = c[0] << 16 | c[1] << 8 | c[2]
        self._buf = [v] * (self.width * self.height)
        self._dirty = True

    def blit_to_surface(self):
        """Copia framebuffer para pygame.Surface apenas quando necessário."""
        if not self._dirty:
            return
        # pygame.surfarray usa numpy; como evitamos dependência pesada,
        # usamos pixels diretos via PixelArray
        pa = pygame.PixelArray(self.surface)
        for y in range(self.height):
            base = y * self.width
            for x in range(self.width):
                v = self._buf[base + x]
                pa[x, y] = v  # pygame armazena como inteiro de cor
        del pa
        self._dirty = False

    # ── put_pixel com espessura ───────────────────────────────
    def put_thick_pixel(self, x: int, y: int, color: tuple, radius: int = 0):
        """Pinta um quadrado de lado (2*radius+1) centrado em (x,y)."""
        if radius == 0:
            self.put_pixel(x, y, color)
        else:
            for dy in range(-radius, radius + 1):
                for dx in range(-radius, radius + 1):
                    self.put_pixel(x + dx, y + dy, color)

    # ── exportar PPM (P6 binário) ─────────────────────────────
    def save_ppm(self, path: str):
        with open(path, "wb") as f:
            header = f"P6\n{self.width} {self.height}\n255\n"
            f.write(header.encode())
            for v in self._buf:
                f.write(bytes([(v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF]))

    # ── exportar BMP (24-bit, sem biblioteca) ─────────────────
    def save_bmp(self, path: str):
        w, h = self.width, self.height
        row_size = (w * 3 + 3) & ~3  # alinhamento 4 bytes
        padding  = row_size - w * 3
        pixel_data_size = row_size * h
        file_size = 54 + pixel_data_size

        with open(path, "wb") as f:
            # BITMAPFILEHEADER (14 bytes)
            f.write(b'BM')
            f.write(struct.pack('<I', file_size))
            f.write(struct.pack('<HH', 0, 0))
            f.write(struct.pack('<I', 54))
            # BITMAPINFOHEADER (40 bytes)
            f.write(struct.pack('<I', 40))
            f.write(struct.pack('<ii', w, -h))  # height negativo = top-down
            f.write(struct.pack('<HH', 1, 24))
            f.write(struct.pack('<I', 0))        # BI_RGB
            f.write(struct.pack('<I', pixel_data_size))
            f.write(struct.pack('<iihh', 2835, 2835, 0, 0))
            # Pixel data (BGR)
            for y in range(h):
                base = y * w
                for x in range(w):
                    v = self._buf[base + x]
                    f.write(bytes([v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF]))
                f.write(b'\x00' * padding)