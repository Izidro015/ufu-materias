"""
Mini Paint - Trabalho 1: Editor Gráfico Raster
Implementa manualmente: put_pixel, get_pixel, Bresenham (linha e círculo),
flood fill, retângulo, polígono, transformações geométricas.
Usa Pygame APENAS para janela, eventos e copiar framebuffer para tela.
"""

import pygame
import sys
import math
import os

from config import *
from framebuffer import Framebuffer
from rasterisacao import *

# ─────────────────────────────────────────────────────────────
#  INTERFACE  (toolbar + lógica principal)
# ─────────────────────────────────────────────────────────────
class MiniPaint:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Mini Paint — CG")
        self.screen = pygame.display.set_mode((WIN_W, WIN_H_TOTAL))
        self.clock  = pygame.time.Clock()

        self.fb = Framebuffer(CANVAS_W, CANVAS_H)

        # estado da ferramenta
        self.tool        = "lapis"
        self.color       = PALETTE[0]   # preto
        self.bg_color    = BG_COLOR
        self.thickness   = "fino"
        self.drawing     = False
        self.start_pos   = None
        self.preview_pos = None

        # polígono: vértices acumulados
        self.poly_pts  = []
        self.poly_done = False

        # preview buffer (cópia do fb para mostrar shape em construção)
        self._preview_buf = None

        # UI
        self._build_ui()

    # ── construção da toolbar ─────────────────────────────────
    def _build_ui(self):
        self.font_sm = pygame.font.SysFont("monospace", 11)
        self.font_md = pygame.font.SysFont("monospace", 12, bold=True)

        self.buttons = {}   # nome → pygame.Rect (em coordenadas de janela)
        ox = CANVAS_W + 8
        y  = 6

        # título
        self._title_rect = pygame.Rect(ox, y, TOOLBAR_W - 16, 20)
        y += 22

        # ferramentas (10 botões × 24px = 240px)
        for tool in TOOLS:
            r = pygame.Rect(ox, y, TOOLBAR_W - 16, 22)
            self.buttons[tool] = r
            y += 24

        y += 4
        # espessura
        self._thick_label_y = y;  y += 15
        self._thick_rects = {}
        for name in THICKNESS_OPTIONS:
            r = pygame.Rect(ox, y, (TOOLBAR_W - 16) // 3 - 2, 20)
            ox2 = ox + THICKNESS_OPTIONS.index(name) * ((TOOLBAR_W - 16) // 3)
            r.x = ox2
            self._thick_rects[name] = r
        y += 26

        # paleta
        y += 4
        self._palette_label_y = y;  y += 15
        self._palette_rects = []
        cols = 6
        sz   = (TOOLBAR_W - 16) // cols - 2
        for i, c in enumerate(PALETTE):
            col = i % cols
            row = i // cols
            r = pygame.Rect(CANVAS_W + 8 + col * (sz + 2),
                            y + row * (sz + 2), sz, sz)
            self._palette_rects.append(r)
        y += ((len(PALETTE) - 1) // cols + 1) * (sz + 2) + 4

        # cor atual
        y += 4
        self._cur_color_y = y;  y += 30

        # ações
        y += 4
        self._btn_novo     = pygame.Rect(CANVAS_W + 8, y, (TOOLBAR_W - 20) // 2, 24);  y += 28
        self._btn_salvar   = pygame.Rect(CANVAS_W + 8, y, TOOLBAR_W - 16, 24);         y += 28
        self._btn_desfazer = pygame.Rect(CANVAS_W + 8, y, TOOLBAR_W - 16, 24);         y += 32

        # botão fechar polígono — aparece abaixo do Desfazer quando polígono está ativo
        self._btn_poly_fechar = pygame.Rect(CANVAS_W + 8, y, TOOLBAR_W - 16, 24)

        # histórico de undo (lista de listas de ints)
        self._history = []
        self._save_snapshot()

    # ── snapshot para undo ────────────────────────────────────
    def _save_snapshot(self):
        self._history.append(list(self.fb._buf))
        if len(self._history) > 20:
            self._history.pop(0)

    def _undo(self):
        if len(self._history) > 1:
            self._history.pop()
            self.fb._buf = list(self._history[-1])
            self.fb._dirty = True

    # ── raio de espessura (em pixels ao redor do centro) ──────
    @property
    def _radius(self):
        return {k: (0, 1, 3) for k in ["fino","médio","grosso"]}[self.thickness][
            THICKNESS_OPTIONS.index(self.thickness)]

    # ── converte posição de janela → canvas ───────────────────
    def _to_canvas(self, pos):
        return (pos[0], pos[1])  # canvas começa em (0,0)

    # ── salva preview do framebuffer ──────────────────────────
    def _save_preview(self):
        self._preview_buf = list(self.fb._buf)

    def _restore_preview(self):
        if self._preview_buf:
            self.fb._buf = list(self._preview_buf)
            self.fb._dirty = True

    # ── draw preview de shape em construção ───────────────────
    def _draw_preview(self, cur_pos):
        if self.start_pos is None or self._preview_buf is None:
            return
        self._restore_preview()
        x0, y0 = self.start_pos
        x1, y1 = cur_pos
        t = self.tool
        r = self._radius
        if t == "linha":
            bresenham_line(self.fb, x0, y0, x1, y1, self.color, r)
        elif t == "retangulo":
            draw_rectangle(self.fb, x0, y0, x1, y1, self.color, r)
        elif t == "retangulo_f":
            filled_rectangle(self.fb, x0, y0, x1, y1, self.color)
        elif t in ("circulo", "circulo_f"):
            rad = int(math.hypot(x1 - x0, y1 - y0))
            if t == "circulo":
                bresenham_circle(self.fb, x0, y0, rad, self.color, r)
            else:
                filled_circle(self.fb, x0, y0, rad, self.color)

    # ── renderiza toolbar ─────────────────────────────────────
    def _draw_toolbar(self):
        # fundo
        pygame.draw.rect(self.screen, (30, 30, 35),
                         (CANVAS_W, 0, TOOLBAR_W, WIN_H_TOTAL))
        pygame.draw.line(self.screen, (80, 80, 90),
                         (CANVAS_W, 0), (CANVAS_W, WIN_H_TOTAL), 2)

        # título
        txt = self.font_md.render("Mini Paint", True, (200, 220, 255))
        self.screen.blit(txt, (CANVAS_W + 8, 10))

        # ferramentas
        for name, rect in self.buttons.items():
            active = (name == self.tool)
            bg = (60, 130, 200) if active else (50, 50, 58)
            pygame.draw.rect(self.screen, bg, rect, border_radius=4)
            txt = self.font_sm.render(TOOL_LABELS[name], True,
                                      (255, 255, 255) if active else (180, 180, 190))
            self.screen.blit(txt, (rect.x + 4, rect.y + 6))

        # espessura
        txt = self.font_sm.render("Espessura:", True, (160, 160, 170))
        self.screen.blit(txt, (CANVAS_W + 8, self._thick_label_y))
        for name, rect in self._thick_rects.items():
            active = (name == self.thickness)
            bg = (60, 130, 200) if active else (50, 50, 58)
            pygame.draw.rect(self.screen, bg, rect, border_radius=3)
            label = name[0].upper()
            txt = self.font_sm.render(label, True, (255,255,255))
            self.screen.blit(txt, (rect.x + 5, rect.y + 5))

        # paleta
        txt = self.font_sm.render("Paleta:", True, (160, 160, 170))
        self.screen.blit(txt, (CANVAS_W + 8, self._palette_label_y))
        for i, (rect, col) in enumerate(zip(self._palette_rects, PALETTE)):
            pygame.draw.rect(self.screen, col, rect, border_radius=2)
            if col == self.color:
                pygame.draw.rect(self.screen, (255, 255, 100), rect, 2, border_radius=2)

        # cor atual
        pygame.draw.rect(self.screen, (60, 60, 70),
                         (CANVAS_W + 8, self._cur_color_y, TOOLBAR_W - 16, 34),
                         border_radius=4)
        pygame.draw.rect(self.screen, self.color,
                         (CANVAS_W + 12, self._cur_color_y + 4, 26, 26),
                         border_radius=3)
        txt = self.font_sm.render(f"RGB{self.color}", True, (200, 200, 200))
        self.screen.blit(txt, (CANVAS_W + 42, self._cur_color_y + 10))

        # botões de ação
        def draw_btn(rect, label, col=(70, 70, 80)):
            pygame.draw.rect(self.screen, col, rect, border_radius=4)
            t = self.font_sm.render(label, True, (220, 220, 230))
            self.screen.blit(t, (rect.x + 4, rect.y + 7))

        draw_btn(self._btn_novo,     "Novo",    (80, 40, 40))
        draw_btn(self._btn_salvar,   "Salvar BMP")
        draw_btn(self._btn_desfazer, "Desfazer (Ctrl+Z)")

        # polígono: dica
        if self.tool == "poligono":
            pts_txt = f"Vértices: {len(self.poly_pts)}"
            txt = self.font_sm.render(pts_txt, True, (180, 230, 180))
            self.screen.blit(txt, (CANVAS_W + 8, self._btn_poly_fechar.y - 16))
            draw_btn(self._btn_poly_fechar, "Fechar Polígono", (40, 100, 60))

    # ── lida com clique na toolbar ────────────────────────────
    def _handle_toolbar_click(self, pos):
        # ferramentas
        for name, rect in self.buttons.items():
            if rect.collidepoint(pos):
                self.tool = name
                if name == "poligono":
                    self.poly_pts  = []
                    self.poly_done = False
                return True

        # espessura
        for name, rect in self._thick_rects.items():
            if rect.collidepoint(pos):
                self.thickness = name;  return True

        # paleta
        for rect, col in zip(self._palette_rects, PALETTE):
            if rect.collidepoint(pos):
                self.color = col;  return True

        # botões de ação
        if self._btn_novo.collidepoint(pos):
            self._save_snapshot()
            self.fb.clear()
            return True
        if self._btn_salvar.collidepoint(pos):
            self._do_save()
            return True

        if self._btn_desfazer.collidepoint(pos):
            self._undo();  return True

        # polígono fechar
        if self.tool == "poligono" and self._btn_poly_fechar.collidepoint(pos):
            self._finalize_polygon()
            return True
        return False

    # ── salvar arquivo ────────────────────────────────────────
    def _do_save(self):
        path = os.path.join(os.path.expanduser("~"), "mini_paint_output.bmp")
        self.fb.save_bmp(path)
        # também salva PPM
        ppm_path = path.replace(".bmp", ".ppm")
        self.fb.save_ppm(ppm_path)
        pygame.display.set_caption(f"Mini Paint — Salvo em {path}")

    # ── finaliza polígono ─────────────────────────────────────
    def _finalize_polygon(self):
        if len(self.poly_pts) >= 3:
            self._save_snapshot()
            r = self._radius
            draw_polygon(self.fb, self.poly_pts, self.color, r)
        self.poly_pts  = []
        self.poly_done = False

    # ── loop principal ────────────────────────────────────────
    def run(self):
        running = True
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                # ── teclado ──
                elif event.type == pygame.KEYDOWN:
                    ctrl = pygame.key.get_mods() & pygame.KMOD_CTRL
                    if ctrl and event.key == pygame.K_z:
                        self._undo()
                    elif ctrl and event.key == pygame.K_s:
                        self._do_save()
                    elif event.key == pygame.K_n:
                        self._save_snapshot();  self.fb.clear()
                    # atalhos de ferramentas
                    keys = {pygame.K_p:"lapis", pygame.K_e:"borracha",
                            pygame.K_l:"linha", pygame.K_r:"retangulo",
                            pygame.K_f:"retangulo_f", pygame.K_c:"circulo",
                            pygame.K_o:"circulo_f", pygame.K_b:"balde",
                            pygame.K_g:"poligono"}
                    if event.key in keys:
                        self.tool = keys[event.key]
                        if self.tool == "poligono":
                            self.poly_pts = [];  self.poly_done = False

                # ── mouse ──
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button != 1:
                        continue  # ignora scroll (botões 4/5) e botão direito
                    pos = event.pos
                    if pos[0] >= CANVAS_W:
                        self._handle_toolbar_click(pos)
                    else:
                        cx, cy = self._to_canvas(pos)
                        if self.tool == "balde":
                            self._save_snapshot()
                            flood_fill(self.fb, cx, cy, self.color)
                        elif self.tool == "poligono":
                            self.poly_pts.append((cx, cy))
                            self.fb.put_thick_pixel(cx, cy, self.color, 2)
                            if len(self.poly_pts) >= 2:
                                x0,y0 = self.poly_pts[-2]
                                bresenham_line(self.fb,x0,y0,cx,cy,self.color,self._radius)
                        else:
                            self.drawing   = True
                            self.start_pos = (cx, cy)
                            self._save_preview()
                            if self.tool in ("lapis", "borracha"):
                                col = self.color if self.tool == "lapis" else self.bg_color
                                self.fb.put_thick_pixel(cx, cy, col, self._radius)

                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1 and self.drawing:
                        pos = event.pos
                        t = self.tool;  r = self._radius
                        if t in ("lapis", "borracha"):
                            # Lápis e borracha desenham progressivamente no _buf
                            # durante o MOUSEMOTION — não há preview para restaurar.
                            # Só salvamos o snapshot para o undo.
                            self._save_snapshot()
                        elif pos[0] < CANVAS_W:
                            cx, cy = self._to_canvas(pos)
                            # Shapes (linha, retângulo, círculo): restaura o estado
                            # pré-preview e redesenha o shape final definitivo.
                            self._restore_preview()
                            x0, y0 = self.start_pos
                            self._save_snapshot()
                            if t == "linha":
                                bresenham_line(self.fb, x0, y0, cx, cy, self.color, r)
                            elif t == "retangulo":
                                draw_rectangle(self.fb, x0, y0, cx, cy, self.color, r)
                            elif t == "retangulo_f":
                                filled_rectangle(self.fb, x0, y0, cx, cy, self.color)
                            elif t == "circulo":
                                rad = int(math.hypot(cx-x0, cy-y0))
                                bresenham_circle(self.fb, x0, y0, rad, self.color, r)
                            elif t == "circulo_f":
                                rad = int(math.hypot(cx-x0, cy-y0))
                                filled_circle(self.fb, x0, y0, rad, self.color)
                        self.drawing      = False
                        self.start_pos    = None
                        self._preview_buf = None

                elif event.type == pygame.MOUSEMOTION:
                    pos = event.pos
                    if pos[0] < CANVAS_W:
                        cx, cy = self._to_canvas(pos)
                        if self.drawing:
                            if self.tool in ("lapis", "borracha"):
                                col = self.color if self.tool == "lapis" else self.bg_color
                                # interpola com Bresenham até posição anterior
                                if self.preview_pos:
                                    px, py = self.preview_pos
                                    bresenham_line(self.fb, px, py, cx, cy, col, self._radius)
                                else:
                                    self.fb.put_thick_pixel(cx, cy, col, self._radius)
                            else:
                                self._draw_preview((cx, cy))
                        self.preview_pos = (cx, cy)

            # ── renderização ──
            # 1. framebuffer → surface (só quando sujo)
            self.fb.blit_to_surface()
            self.screen.blit(self.fb.surface, (0, 0))

            # 2. toolbar
            self._draw_toolbar()

            # 3. cursor na barra de status (rodapé)
            mx, my = pygame.mouse.get_pos()
            if mx < CANVAS_W:
                status = f"({mx}, {my})  |  {TOOL_LABELS[self.tool]}  |  {self.thickness}"
                txt = self.font_sm.render(status, True, (180, 180, 200))
                pygame.draw.rect(self.screen, (20, 20, 25),
                                 (0, WIN_H - 16, CANVAS_W, 16))
                self.screen.blit(txt, (4, WIN_H - 14))

            pygame.display.flip()
            self.clock.tick(FPS)

        pygame.quit()
        sys.exit()

# ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = MiniPaint()
    app.run()