from collections import deque
from framebuffer import Framebuffer

# ─────────────────────────────────────────────────────────────
#  ALGORITMOS DE RASTERIZAÇÃO (todos implementados à mão)
# ─────────────────────────────────────────────────────────────

def bresenham_line(fb: Framebuffer, x0, y0, x1, y1, color, radius=0):
    """Algoritmo de Bresenham para rasterização de linhas."""
    dx = abs(x1 - x0);  dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy
    while True:
        fb.put_thick_pixel(x0, y0, color, radius)
        if x0 == x1 and y0 == y1:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy;  x0 += sx
        if e2 <  dx:
            err += dx;  y0 += sy

def bresenham_circle(fb: Framebuffer, cx, cy, r, color, radius=0):
    """Algoritmo de Bresenham (ponto médio) para círculos."""
    x, y = 0, r
    d = 3 - 2 * r
    def _plot8(px, py):
        for ox, oy in [(px,py),(-px,py),(px,-py),(-px,-py),
                       (py,px),(-py,px),(py,-px),(-py,-px)]:
            fb.put_thick_pixel(cx+ox, cy+oy, color, radius)
    _plot8(x, y)
    while y >= x:
        x += 1
        if d > 0:
            y -= 1;  d += 4*(x - y) + 10
        else:
            d += 4*x + 6
        _plot8(x, y)

def filled_circle(fb: Framebuffer, cx, cy, r, color):
    """Círculo preenchido via Bresenham — preenche scanlines."""
    x, y = 0, r
    d = 3 - 2 * r
    def _hline(lx, rx, ly):
        for px in range(lx, rx + 1):
            fb.put_pixel(px, ly, color)
    _hline(cx - y, cx + y, cy)
    while y >= x:
        x += 1
        if d > 0:
            y -= 1;  d += 4*(x - y) + 10
        else:
            d += 4*x + 6
        _hline(cx - x, cx + x, cy + y)
        _hline(cx - x, cx + x, cy - y)
        _hline(cx - y, cx + y, cy + x)
        _hline(cx - y, cx + y, cy - x)

def draw_rectangle(fb: Framebuffer, x0, y0, x1, y1, color, radius=0):
    """Retângulo vazado com Bresenham nas 4 arestas."""
    bresenham_line(fb, x0, y0, x1, y0, color, radius)
    bresenham_line(fb, x1, y0, x1, y1, color, radius)
    bresenham_line(fb, x1, y1, x0, y1, color, radius)
    bresenham_line(fb, x0, y1, x0, y0, color, radius)

def filled_rectangle(fb: Framebuffer, x0, y0, x1, y1, color):
    """Retângulo preenchido scanline por scanline."""
    lx, rx = (x0, x1) if x0 <= x1 else (x1, x0)
    ty, by = (y0, y1) if y0 <= y1 else (y1, y0)
    for y in range(ty, by + 1):
        for x in range(lx, rx + 1):
            fb.put_pixel(x, y, color)

def draw_polygon(fb: Framebuffer, points, color, radius=0):
    """Polígono vazado — liga vértices consecutivos com Bresenham."""
    n = len(points)
    for i in range(n):
        x0, y0 = points[i]
        x1, y1 = points[(i + 1) % n]
        bresenham_line(fb, x0, y0, x1, y1, color, radius)

def filled_polygon(fb: Framebuffer, points, color):
    """
    Preenchimento de polígono convexo/côncavo por scan-line.
    Para cada linha Y, acha interseções com as arestas e preenche.
    """
    if len(points) < 3:
        return
    ys = [p[1] for p in points]
    min_y, max_y = max(0, min(ys)), min(fb.height - 1, max(ys))
    n = len(points)
    for y in range(min_y, max_y + 1):
        xs = []
        for i in range(n):
            x0, y0 = points[i]
            x1, y1 = points[(i + 1) % n]
            if y0 == y1:
                continue
            if min(y0, y1) <= y < max(y0, y1):
                x = x0 + (y - y0) * (x1 - x0) / (y1 - y0)
                xs.append(int(x))
        xs.sort()
        for k in range(0, len(xs) - 1, 2):
            for px in range(xs[k], xs[k + 1] + 1):
                fb.put_pixel(px, y, color)

# ── Flood Fill (BFS com queue — sem recursão para evitar stack overflow) ──────
def flood_fill(fb: Framebuffer, x, y, new_color):
    """Flood fill 4-conectado iterativo com deque."""
    old_color = fb.get_pixel(x, y)
    if old_color == new_color:
        return
    q = deque()
    q.append((x, y))
    visited = set()
    visited.add((x, y))
    while q:
        cx, cy = q.popleft()
        if fb.get_pixel(cx, cy) != old_color:
            continue
        fb.put_pixel(cx, cy, new_color)
        for nx, ny in [(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)]:
            if (nx, ny) not in visited and 0 <= nx < fb.width and 0 <= ny < fb.height:
                if fb.get_pixel(nx, ny) == old_color:
                    visited.add((nx, ny))
                    q.append((nx, ny))