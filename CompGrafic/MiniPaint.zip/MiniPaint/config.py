# config.py

CANVAS_W, CANVAS_H = 800, 600
TOOLBAR_W = 190
WIN_W = CANVAS_W + TOOLBAR_W
WIN_H = CANVAS_H        
WIN_H_TOTAL = WIN_H     
FPS = 60

# Cores pré-definidas (R, G, B)
PALETTE = [
    (0,   0,   0),    # Preto
    (255, 255, 255),  # Branco
    (220,  30,  30),  # Vermelho
    ( 30, 180,  30),  # Verde
    ( 30,  80, 220),  # Azul
    (240, 210,   0),  # Amarelo
    (  0, 210, 210),  # Ciano
    (210,   0, 210),  # Magenta
    (255, 140,   0),  # Laranja
    (140,   0, 200),  # Roxo
    (139,  90,  43),  # Marrom
    (128, 128, 128),  # Cinza
]

BG_COLOR = (255, 255, 255)  

THICKNESS = {"fino": 1, "médio": 3, "grosso": 6}
THICKNESS_OPTIONS = ["fino", "médio", "grosso"]

TOOLS = [
    "lapis", "borracha", "linha", "retangulo", "retangulo_f",
    "circulo", "circulo_f", "balde", "poligono",
]

TOOL_LABELS = {
    "lapis":       "✏ Lápis",
    "borracha":    "⬜ Borracha",
    "linha":       "╱ Linha",
    "retangulo":   "▭ Ret. Vazado",
    "retangulo_f": "▬ Ret. Cheio",
    "circulo":     "○ Círc. Vazado",
    "circulo_f":   "● Círc. Cheio",
    "balde":       "🪣 Balde",
    "poligono":    "⬡ Polígono",
}