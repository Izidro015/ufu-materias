import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Map;

public class ClienteResultados {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            
            ServicoDeResultados stub = (ServicoDeResultados) registry.lookup("ServicoDeResultados");

            Map<String, Integer> resultados = stub.getResultados();

            System.out.println("\n--- APURAÇÃO ATUAL ---");
            for (Map.Entry<String, Integer> entry : resultados.entrySet()) {
                System.out.println("Candidato: " + entry.getKey() + " | Votos: " + entry.getValue());
            }

        } catch (Exception e) {
            System.err.println("Erro ao buscar resultados: " + e.toString());
            e.printStackTrace();
        }
    }
}