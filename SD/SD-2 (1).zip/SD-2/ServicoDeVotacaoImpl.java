import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

public class ServicoDeVotacaoImpl extends UnicastRemoteObject implements ServicoDeVotacao {
    
    public static Map<String, Integer> votos = new HashMap<>();

    public ServicoDeVotacaoImpl() throws RemoteException {
        super();
        if (votos.isEmpty()) {
            votos.put("Candidato A", 0);
            votos.put("Candidato B", 0);
        }
    }

    @Override
    public void votar(String eleitor, String candidato) throws RemoteException {
        String candidatoKey = candidato.trim();
        
        synchronized (votos) { 
            if (votos.containsKey(candidatoKey)) {
                votos.put(candidatoKey, votos.get(candidatoKey) + 1);
            } else {
                votos.put(candidatoKey, 1);
            }
        }
        System.out.println("Voto registrado: " + eleitor + " -> " + candidatoKey);
    }
}