import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ServidorRMI {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.createRegistry(1099);

            ServicoDeVotacaoImpl votacaoService = new ServicoDeVotacaoImpl();
            registry.rebind("ServicoDeVotacao", votacaoService);

            ServicoDeResultadosImpl resultadosService = new ServicoDeResultadosImpl();
            registry.rebind("ServicoDeResultados", resultadosService);

            System.out.println("Servidor RMI pronto e aguardando conexões...");
        } catch (Exception e) {
            System.err.println("Erro no servidor: " + e.toString());
            e.printStackTrace();
        }
    }
}