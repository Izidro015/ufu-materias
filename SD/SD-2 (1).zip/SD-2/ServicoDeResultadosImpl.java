import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Map;

public class ServicoDeResultadosImpl extends UnicastRemoteObject implements ServicoDeResultados {

    public ServicoDeResultadosImpl() throws RemoteException {
        super();
    }

    @Override
    public Map<String, Integer> getResultados() throws RemoteException {
        return ServicoDeVotacaoImpl.votos;
    }
}