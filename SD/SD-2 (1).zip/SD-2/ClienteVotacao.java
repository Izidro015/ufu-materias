import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class ClienteVotacao {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            
            ServicoDeVotacao stub = (ServicoDeVotacao) registry.lookup("ServicoDeVotacao");

            Scanner scanner = new Scanner(System.in);

            System.out.println("--- URNA ELETRÔNICA REMOTA ---");
            System.out.print("Digite seu nome de eleitor: ");
            String eleitor = scanner.nextLine();

            System.out.println("\nCandidatos disponíveis: Candidato A, Candidato B");
            System.out.print("Digite o nome do candidato: ");
            String candidato = scanner.nextLine();

            stub.votar(eleitor, candidato);
            
            System.out.println("Sucesso! Seu voto foi computado.");
            
            scanner.close();
        } catch (Exception e) {
            System.err.println("Erro no cliente de votação: " + e.toString());
            e.printStackTrace();
        }
    }
}