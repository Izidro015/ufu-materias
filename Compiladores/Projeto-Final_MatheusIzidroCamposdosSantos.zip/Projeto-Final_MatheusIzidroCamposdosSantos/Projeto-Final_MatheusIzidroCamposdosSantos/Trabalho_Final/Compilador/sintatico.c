#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sintatico.h"

#define VAZIO -1
#define EPSILON -2

int tabela[50][50];

const char *nomes_tokens[] = {
    "Fim de Arquivo (EOF)", "Erro", "Identificador (ID)", "'main'", "'void'", "'int'", "'char'", "'float'",
    "'if'", "'then'", "'elsif'", "'else'", "'while'", "'do'", "'for'",
    "Numero Inteiro", "Numero Float", "Caractere",
    "Operador de Soma", "Operador de Multiplicacao", "Operador de Exponenciacao", "Operador Relacional", "Atribuicao (:=)",
    "Ponto e Virgula (;)", "Virgula (,)", "Abre Parenteses '('", "Fecha Parenteses ')'", "Abre Colchetes '['", "Fecha Colchetes ']'",
    "Comentario", "Espaco em Branco"
};

typedef struct Pilha {
    int dados[1000];
    NoArvore* nos[1000];
    int topo;
} Pilha;

void push(Pilha *p, int val, NoArvore *no) {
    p->topo++;
    p->dados[p->topo] = val;
    p->nos[p->topo] = no;
}

int pop(Pilha *p, NoArvore **no) {
    if (p->topo == -1) return VAZIO;
    if (no) *no = p->nos[p->topo];
    return p->dados[p->topo--];
}

NoArvore* criar_no(int simbolo) {
    NoArvore *novo = (NoArvore*)malloc(sizeof(NoArvore));
    novo->simbolo = simbolo;
    novo->filho = NULL;
    novo->irmao = NULL;
    return novo;
}

void anexar_filho(NoArvore *pai, NoArvore *filho) {
    if (!pai || !filho) return;
    if (!pai->filho) {
        pai->filho = filho;
    } else {
        NoArvore *temp = pai->filho;
        while (temp->irmao) temp = temp->irmao;
        temp->irmao = filho;
    }
}

void inicializar_tabela() {
    for(int i = 0; i < 50; i++)
        for(int j = 0; j < 50; j++)
            tabela[i][j] = VAZIO;

    tabela[NT_PROGRAMA - 100][TIPO_VOID] = 1;
    tabela[NT_PROGRAMA - 100][TIPO_INT] = 1;
    tabela[NT_PROGRAMA - 100][TIPO_CHAR] = 1;
    tabela[NT_PROGRAMA - 100][TIPO_FLOAT] = 1;

    tabela[NT_TIPORETORNO - 100][TIPO_VOID] = 2;
    tabela[NT_TIPORETORNO - 100][TIPO_INT] = 3;
    tabela[NT_TIPORETORNO - 100][TIPO_CHAR] = 4;
    tabela[NT_TIPORETORNO - 100][TIPO_FLOAT] = 5;

    tabela[NT_TIPOVARIAVEL - 100][TIPO_INT] = 6;
    tabela[NT_TIPOVARIAVEL - 100][TIPO_CHAR] = 7;
    tabela[NT_TIPOVARIAVEL - 100][TIPO_FLOAT] = 8;

    tabela[NT_BLOCO - 100][T_ABRECOL] = 9;

    tabela[NT_DECLVARS - 100][TIPO_INT] = 10;
    tabela[NT_DECLVARS - 100][TIPO_CHAR] = 10;
    tabela[NT_DECLVARS - 100][TIPO_FLOAT] = 10;
    tabela[NT_DECLVARS - 100][T_ID] = 11;
    tabela[NT_DECLVARS - 100][T_IF] = 11;
    tabela[NT_DECLVARS - 100][T_WHILE] = 11;
    tabela[NT_DECLVARS - 100][T_DO] = 11;
    tabela[NT_DECLVARS - 100][T_FOR] = 11;
    tabela[NT_DECLVARS - 100][T_FECHACOL] = 11;

    tabela[NT_DECLARACAO - 100][TIPO_INT] = 12;
    tabela[NT_DECLARACAO - 100][TIPO_CHAR] = 12;
    tabela[NT_DECLARACAO - 100][TIPO_FLOAT] = 12;

    tabela[NT_LISTAIDS - 100][T_ID] = 13;

    tabela[NT_RESTOLISTAIDS - 100][T_VIRG] = 14;
    tabela[NT_RESTOLISTAIDS - 100][T_PONTOVIRG] = 15;

    tabela[NT_LISTACOMANDOS - 100][T_ID] = 16;
    tabela[NT_LISTACOMANDOS - 100][T_IF] = 16;
    tabela[NT_LISTACOMANDOS - 100][T_WHILE] = 16;
    tabela[NT_LISTACOMANDOS - 100][T_DO] = 16;
    tabela[NT_LISTACOMANDOS - 100][T_FOR] = 16;
    tabela[NT_LISTACOMANDOS - 100][T_FECHACOL] = 17;

    tabela[NT_COMANDO - 100][T_ID] = 18;
    tabela[NT_COMANDO - 100][T_IF] = 19;
    tabela[NT_COMANDO - 100][T_WHILE] = 20;
    tabela[NT_COMANDO - 100][T_DO] = 21;
    tabela[NT_COMANDO - 100][T_FOR] = 22;

    tabela[NT_ATRIBUICAO - 100][T_ID] = 23;

    tabela[NT_DECISAO - 100][T_IF] = 24;

    tabela[NT_LISTAELSIFS - 100][T_ELSIF] = 25;
    tabela[NT_LISTAELSIFS - 100][T_ELSE] = 26;
    tabela[NT_LISTAELSIFS - 100][T_ID] = 26;
    tabela[NT_LISTAELSIFS - 100][T_IF] = 26;
    tabela[NT_LISTAELSIFS - 100][T_WHILE] = 26;
    tabela[NT_LISTAELSIFS - 100][T_DO] = 26;
    tabela[NT_LISTAELSIFS - 100][T_FOR] = 26;
    tabela[NT_LISTAELSIFS - 100][T_FECHACOL] = 26;

    tabela[NT_OPCIONALELSE - 100][T_ELSE] = 27;
    tabela[NT_OPCIONALELSE - 100][T_ID] = 28;
    tabela[NT_OPCIONALELSE - 100][T_IF] = 28;
    tabela[NT_OPCIONALELSE - 100][T_WHILE] = 28;
    tabela[NT_OPCIONALELSE - 100][T_DO] = 28;
    tabela[NT_OPCIONALELSE - 100][T_FOR] = 28;
    tabela[NT_OPCIONALELSE - 100][T_FECHACOL] = 28;

    tabela[NT_CORPO - 100][T_ID] = 29;
    tabela[NT_CORPO - 100][T_IF] = 29;
    tabela[NT_CORPO - 100][T_WHILE] = 29;
    tabela[NT_CORPO - 100][T_DO] = 29;
    tabela[NT_CORPO - 100][T_FOR] = 29;
    tabela[NT_CORPO - 100][T_ABRECOL] = 30;

    tabela[NT_REPETICAOWHILE - 100][T_WHILE] = 31;
    tabela[NT_REPETICAODOWHILE - 100][T_DO] = 32;
    tabela[NT_REPETICAOFOR - 100][T_FOR] = 33;

    tabela[NT_CONDICAO - 100][T_ABREPAR] = 34;
    tabela[NT_CONDICAO - 100][T_NUM_INT] = 34;
    tabela[NT_CONDICAO - 100][T_NUM_FLOAT] = 34;
    tabela[NT_CONDICAO - 100][T_CHAR] = 34;
    tabela[NT_CONDICAO - 100][T_ID] = 34;
    tabela[NT_CONDICAO - 100][T_SOMA] = 34;

    tabela[NT_EXPRESSAO - 100][T_ABREPAR] = 35;
    tabela[NT_EXPRESSAO - 100][T_NUM_INT] = 35;
    tabela[NT_EXPRESSAO - 100][T_NUM_FLOAT] = 35;
    tabela[NT_EXPRESSAO - 100][T_CHAR] = 35;
    tabela[NT_EXPRESSAO - 100][T_ID] = 35;
    tabela[NT_EXPRESSAO - 100][T_SOMA] = 35;

    tabela[NT_EXPRESSAOLINHA - 100][T_SOMA] = 36;
    tabela[NT_EXPRESSAOLINHA - 100][T_RELOP] = 37;
    tabela[NT_EXPRESSAOLINHA - 100][T_FECHAPAR] = 37;
    tabela[NT_EXPRESSAOLINHA - 100][T_PONTOVIRG] = 37;

    tabela[NT_TERMO - 100][T_ABREPAR] = 38;
    tabela[NT_TERMO - 100][T_NUM_INT] = 38;
    tabela[NT_TERMO - 100][T_NUM_FLOAT] = 38;
    tabela[NT_TERMO - 100][T_CHAR] = 38;
    tabela[NT_TERMO - 100][T_ID] = 38;
    tabela[NT_TERMO - 100][T_SOMA] = 38;

    tabela[NT_TERMOLINHA - 100][T_MULT] = 39;
    tabela[NT_TERMOLINHA - 100][T_SOMA] = 40;
    tabela[NT_TERMOLINHA - 100][T_RELOP] = 40;
    tabela[NT_TERMOLINHA - 100][T_FECHAPAR] = 40;
    tabela[NT_TERMOLINHA - 100][T_PONTOVIRG] = 40;

    tabela[NT_POTENCIA - 100][T_ABREPAR] = 41;
    tabela[NT_POTENCIA - 100][T_NUM_INT] = 41;
    tabela[NT_POTENCIA - 100][T_NUM_FLOAT] = 41;
    tabela[NT_POTENCIA - 100][T_CHAR] = 41;
    tabela[NT_POTENCIA - 100][T_ID] = 41;
    tabela[NT_POTENCIA - 100][T_SOMA] = 41;

    tabela[NT_POTENCIALINHA - 100][T_EXP] = 42;
    tabela[NT_POTENCIALINHA - 100][T_MULT] = 43;
    tabela[NT_POTENCIALINHA - 100][T_SOMA] = 43;
    tabela[NT_POTENCIALINHA - 100][T_RELOP] = 43;
    tabela[NT_POTENCIALINHA - 100][T_FECHAPAR] = 43;
    tabela[NT_POTENCIALINHA - 100][T_PONTOVIRG] = 43;

    tabela[NT_FATOR - 100][T_ABREPAR] = 44;
    tabela[NT_FATOR - 100][T_NUM_INT] = 45;
    tabela[NT_FATOR - 100][T_NUM_FLOAT] = 46;
    tabela[NT_FATOR - 100][T_CHAR] = 47;
    tabela[NT_FATOR - 100][T_ID] = 48;
    tabela[NT_FATOR - 100][T_SOMA] = 49;
}

void imprimir_erro_util(Token t, int terminal_esperado, int nt_topo) {
    printf("\nErro sintatico na linha %d, coluna %d: encontrado '%s'.\n", 
           t.linha, t.coluna, t.atributo[0] != '\0' ? t.atributo : nomes_tokens[t.tipo]);
    
    printf("  -> Esperado: ");
    if (terminal_esperado != -1) {
        printf("%s\n", nomes_tokens[terminal_esperado]);
    } else {
        int first = 1;
        for (int i = 0; i <= T_FECHACOL; i++) {
            if (tabela[nt_topo - 100][i] != VAZIO) {
                if (!first) printf(", ");
                printf("%s", nomes_tokens[i]);
                first = 0;
            }
        }
        printf("\n");
    }
}

void empilhar_producao(Pilha *p, NoArvore *pai, int *simbolos, int qtd) {
    NoArvore *filhos[15];

    for (int i = 0; i < qtd; i++) {
        if (simbolos[i] != EPSILON) {
            filhos[i] = criar_no(simbolos[i]);
            anexar_filho(pai, filhos[i]);
        } else {
            filhos[i] = NULL;
        }
    }

    for (int i = qtd - 1; i >= 0; i--) {
        if (simbolos[i] != EPSILON) {
            push(p, simbolos[i], filhos[i]);
        }
    }
}

NoArvore* analisar_sintaxe(FILE *arquivo) {
    inicializar_tabela();
    Pilha p;
    p.topo = -1;

    NoArvore *raiz = criar_no(NT_PROGRAMA);
    push(&p, T_EOF, NULL);
    push(&p, NT_PROGRAMA, raiz);

    Token a = proximo_token(arquivo);
    while(a.tipo == T_WS || a.tipo == T_COMENTARIO) a = proximo_token(arquivo);

    int topo;
    NoArvore *no_atual;

    while (p.topo != -1) {
        topo = pop(&p, &no_atual);

        if (topo == a.tipo) {
            if (no_atual) no_atual->token = a;
            a = proximo_token(arquivo);
            while(a.tipo == T_WS || a.tipo == T_COMENTARIO) a = proximo_token(arquivo);
        } else if (topo < 100) {
            //ERRO TIPO 1: O topo da pilha era um Terminal, mas o token lido foi diferente
            imprimir_erro_util(a, topo, -1);
            exit(1); //Parada Imediata
        } else {
            int prod = tabela[topo - 100][a.tipo];
            
            if (prod == VAZIO) {
                //ERRO TIPO 2: Celula vazia na tabela de transição
                imprimir_erro_util(a, -1, topo);
                exit(1); //Parada Imediata (não tem panic mode)
            }

            int simbolos[15];
            int qtd = 0;

            switch(prod) {
                case 1:  simbolos[0] = NT_TIPORETORNO; simbolos[1] = T_MAIN; simbolos[2] = T_ABREPAR; simbolos[3] = T_FECHAPAR; simbolos[4] = NT_BLOCO; qtd = 5; break;
                case 2:  simbolos[0] = TIPO_VOID; qtd = 1; break;
                case 3:  simbolos[0] = TIPO_INT; qtd = 1; break;
                case 4:  simbolos[0] = TIPO_CHAR; qtd = 1; break;
                case 5:  simbolos[0] = TIPO_FLOAT; qtd = 1; break;
                case 6:  simbolos[0] = TIPO_INT; qtd = 1; break;
                case 7:  simbolos[0] = TIPO_CHAR; qtd = 1; break;
                case 8:  simbolos[0] = TIPO_FLOAT; qtd = 1; break;
                case 9:  simbolos[0] = T_ABRECOL; simbolos[1] = NT_DECLVARS; simbolos[2] = NT_LISTACOMANDOS; simbolos[3] = T_FECHACOL; qtd = 4; break;
                case 10: simbolos[0] = NT_DECLARACAO; simbolos[1] = NT_DECLVARS; qtd = 2; break;
                case 11: simbolos[0] = EPSILON; qtd = 1; break;
                case 12: simbolos[0] = NT_TIPOVARIAVEL; simbolos[1] = NT_LISTAIDS; simbolos[2] = T_PONTOVIRG; qtd = 3; break;
                case 13: simbolos[0] = T_ID; simbolos[1] = NT_RESTOLISTAIDS; qtd = 2; break;
                case 14: simbolos[0] = T_VIRG; simbolos[1] = NT_LISTAIDS; qtd = 2; break;
                case 15: simbolos[0] = EPSILON; qtd = 1; break;
                case 16: simbolos[0] = NT_COMANDO; simbolos[1] = NT_LISTACOMANDOS; qtd = 2; break;
                case 17: simbolos[0] = EPSILON; qtd = 1; break;
                case 18: simbolos[0] = NT_ATRIBUICAO; qtd = 1; break;
                case 19: simbolos[0] = NT_DECISAO; qtd = 1; break;
                case 20: simbolos[0] = NT_REPETICAOWHILE; qtd = 1; break;
                case 21: simbolos[0] = NT_REPETICAODOWHILE; qtd = 1; break;
                case 22: simbolos[0] = NT_REPETICAOFOR; qtd = 1; break;
                case 23: simbolos[0] = T_ID; simbolos[1] = T_ASSIGN; simbolos[2] = NT_EXPRESSAO; simbolos[3] = T_PONTOVIRG; qtd = 4; break;
                case 24: simbolos[0] = T_IF; simbolos[1] = T_ABREPAR; simbolos[2] = NT_CONDICAO; simbolos[3] = T_FECHAPAR; simbolos[4] = T_THEN; simbolos[5] = NT_CORPO; simbolos[6] = NT_LISTAELSIFS; simbolos[7] = NT_OPCIONALELSE; qtd = 8; break;
                case 25: simbolos[0] = T_ELSIF; simbolos[1] = T_ABREPAR; simbolos[2] = NT_CONDICAO; simbolos[3] = T_FECHAPAR; simbolos[4] = T_THEN; simbolos[5] = NT_CORPO; simbolos[6] = NT_LISTAELSIFS; qtd = 7; break;
                case 26: simbolos[0] = EPSILON; qtd = 1; break;
                case 27: simbolos[0] = T_ELSE; simbolos[1] = NT_CORPO; qtd = 2; break;
                case 28: simbolos[0] = EPSILON; qtd = 1; break;
                case 29: simbolos[0] = NT_COMANDO; qtd = 1; break;
                case 30: simbolos[0] = NT_BLOCO; qtd = 1; break;
                case 31: simbolos[0] = T_WHILE; simbolos[1] = T_ABREPAR; simbolos[2] = NT_CONDICAO; simbolos[3] = T_FECHAPAR; simbolos[4] = T_DO; simbolos[5] = NT_CORPO; qtd = 6; break;
                case 32: simbolos[0] = T_DO; simbolos[1] = NT_CORPO; simbolos[2] = T_WHILE; simbolos[3] = T_ABREPAR; simbolos[4] = NT_CONDICAO; simbolos[5] = T_FECHAPAR; simbolos[6] = T_PONTOVIRG; qtd = 7; break;
                case 33: simbolos[0] = T_FOR; simbolos[1] = T_ABREPAR; simbolos[2] = T_ID; simbolos[3] = T_PONTOVIRG; simbolos[4] = T_NUM_INT; simbolos[5] = T_PONTOVIRG; simbolos[6] = T_NUM_INT; simbolos[7] = T_PONTOVIRG; simbolos[8] = NT_EXPRESSAO; simbolos[9] = T_FECHAPAR; simbolos[10] = NT_CORPO; qtd = 11; break;
                case 34: simbolos[0] = NT_EXPRESSAO; simbolos[1] = T_RELOP; simbolos[2] = NT_EXPRESSAO; qtd = 3; break;
                case 35: simbolos[0] = NT_TERMO; simbolos[1] = NT_EXPRESSAOLINHA; qtd = 2; break;
                case 36: simbolos[0] = T_SOMA; simbolos[1] = NT_TERMO; simbolos[2] = NT_EXPRESSAOLINHA; qtd = 3; break;
                case 37: simbolos[0] = EPSILON; qtd = 1; break;
                case 38: simbolos[0] = NT_POTENCIA; simbolos[1] = NT_TERMOLINHA; qtd = 2; break;
                case 39: simbolos[0] = T_MULT; simbolos[1] = NT_POTENCIA; simbolos[2] = NT_TERMOLINHA; qtd = 3; break;
                case 40: simbolos[0] = EPSILON; qtd = 1; break;
                case 41: simbolos[0] = NT_FATOR; simbolos[1] = NT_POTENCIALINHA; qtd = 2; break;
                case 42: simbolos[0] = T_EXP; simbolos[1] = NT_FATOR; simbolos[2] = NT_POTENCIALINHA; qtd = 3; break;
                case 43: simbolos[0] = EPSILON; qtd = 1; break;
                case 44: simbolos[0] = T_ABREPAR; simbolos[1] = NT_EXPRESSAO; simbolos[2] = T_FECHAPAR; qtd = 3; break;
                case 45: simbolos[0] = T_NUM_INT; qtd = 1; break;
                case 46: simbolos[0] = T_NUM_FLOAT; qtd = 1; break;
                case 47: simbolos[0] = T_CHAR; qtd = 1; break;
                case 48: simbolos[0] = T_ID; qtd = 1; break;
                case 49: simbolos[0] = T_SOMA; simbolos[1] = NT_FATOR; qtd = 2; break;
            }

            empilhar_producao(&p, no_atual, simbolos, qtd);
        }
    }
    
    printf("\nAnalise Sintatica concluida com sucesso!\n");
    return raiz;
}