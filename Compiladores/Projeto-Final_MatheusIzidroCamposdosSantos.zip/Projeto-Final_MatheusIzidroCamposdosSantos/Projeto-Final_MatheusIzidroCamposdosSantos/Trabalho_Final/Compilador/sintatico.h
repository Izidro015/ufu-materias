#ifndef SINTATICO_H
#define SINTATICO_H

#include "lexico.h"

typedef enum {
    NT_PROGRAMA = 100, NT_TIPORETORNO, NT_TIPOVARIAVEL, NT_BLOCO, NT_DECLVARS,
    NT_DECLARACAO, NT_LISTAIDS, NT_RESTOLISTAIDS, NT_LISTACOMANDOS, NT_COMANDO,
    NT_ATRIBUICAO, NT_DECISAO, NT_LISTAELSIFS, NT_OPCIONALELSE, NT_CORPO,
    NT_REPETICAOWHILE, NT_REPETICAODOWHILE, NT_REPETICAOFOR, NT_CONDICAO,
    NT_EXPRESSAO, NT_EXPRESSAOLINHA, NT_TERMO, NT_TERMOLINHA, NT_POTENCIA,
    NT_POTENCIALINHA, NT_FATOR
} NaoTerminal;

typedef struct NoArvore {
    int simbolo;
    Token token;
    struct NoArvore *filho;
    struct NoArvore *irmao;
} NoArvore;

NoArvore* analisar_sintaxe(FILE *arquivo);

#endif