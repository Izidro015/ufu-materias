#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "lexico.h"

int linha_atual = 1;
int coluna_atual = 0;

char ler_char(FILE *f) {
    char c = fgetc(f);
    if (c == '\n') {
        linha_atual++;
        coluna_atual = 0;
    } else {
        coluna_atual++;
    }
    return c;
}

void devolver_char(FILE *f, char c) {
    if (c != EOF) {
        ungetc(c, f);
        if (c == '\n') {
            linha_atual--;
        } else {
            coluna_atual--;
        }
    }
}

//Tabela de Símbolos
TokenType verificar_palavra_reservada(char *lexema) {
    if (strcmp(lexema, "main") == 0) return T_MAIN;
    if (strcmp(lexema, "void") == 0) return TIPO_VOID;
    if (strcmp(lexema, "int") == 0)  return TIPO_INT;
    if (strcmp(lexema, "char") == 0) return TIPO_CHAR;
    if (strcmp(lexema, "float") == 0)return TIPO_FLOAT;
    if (strcmp(lexema, "if") == 0)   return T_IF;
    if (strcmp(lexema, "then") == 0) return T_THEN;
    if (strcmp(lexema, "elsif") == 0)return T_ELSIF;
    if (strcmp(lexema, "else") == 0) return T_ELSE;
    if (strcmp(lexema, "while") == 0)return T_WHILE;
    if (strcmp(lexema, "do") == 0)   return T_DO;
    if (strcmp(lexema, "for") == 0)  return T_FOR;
    
    return T_ID; //Se não for reservada, é ID
}

//Analisador Léxico 
Token proximo_token(FILE *arquivo) {
    Token token;
    token.atributo[0] = '\0';
    token.linha = linha_atual;
    token.coluna = coluna_atual;
    char c;
    char lexema[100];
    int i = 0;
    int estado = 0;

    lexema[0] = '\0';

    while (1) {
        c = ler_char(arquivo);
        
        switch (estado) {
            case 0:
                if (c == EOF) {
                    token.tipo = T_EOF;
                    return token;
                }
                //T_WS (Ignora e reinicia)
                else if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    estado = 0; 
                }
                //IDs
                else if (isalpha(c) || c == '_') {
                    lexema[i++] = c;
                    estado = 2; //Lê o ID ou a palavra reservada de acordo com a tabela de símbolos
                }
                //Números
                else if (isdigit(c)) {
                    lexema[i++] = c;
                    estado = 74; //Verifica se é float ou int
                }
                else if (c == '+') { 
                    token.tipo = T_SOMA; strcpy(token.atributo, "mais"); return token; 
                }
                else if (c == '-') { 
                    token.tipo = T_SOMA; strcpy(token.atributo, "menos"); return token; 
                }
                else if (c == '*') { estado = 92; } //Vai pro case 92 pois * pode ser tanto T_MULT e T_EXP
                else if (c == '/') { 
                    token.tipo = T_MULT; strcpy(token.atributo, "divisao"); return token; 
                }
                else if (c == '<') { estado = 99; }
                else if (c == '>') { estado = 102; }
                else if (c == '=') { estado = 105; }
                else if (c == '!') { estado = 107; }
                else if (c == ':') { estado = 110; }
                else if (c == ';') { token.tipo = T_PONTOVIRG; return token; }
                else if (c == ',') { token.tipo = T_VIRG; return token; }
                else if (c == '(') { token.tipo = T_ABREPAR; return token; }
                else if (c == ')') { token.tipo = T_FECHAPAR; return token; }
                else if (c == '[') { token.tipo = T_ABRECOL; return token; }
                else if (c == ']') { token.tipo = T_FECHACOL; return token; }
                else if (c == '\'') { estado = 85; } //T_CHAR
                else if (c == '{') { estado = 125; } 
                else {
                    printf("Erro: Caractere invalido '%c' na linha %d\n", c, linha_atual);
                    token.tipo = T_ERRO;
                    return token;
                }
                break;

            case 2: //ID e Palavras Reservadas
                if (isalnum(c) || c == '_') {
                    lexema[i++] = c;
                } else {
                    devolver_char(arquivo, c);
                    lexema[i] = '\0';
                    token.tipo = verificar_palavra_reservada(lexema);
                    if (token.tipo == T_ID) strcpy(token.atributo, lexema);
                    else token.atributo[0] = '\0'; 
                    token.linha = linha_atual;
                    return token;
                }
                break;

            case 74: //Numeros int e float
                if (isdigit(c)) {
                    lexema[i++] = c;
                } else if (c == '.') {
                    lexema[i++] = c;
                    estado = 78; //Float
                } else if (c == 'E') {
                    lexema[i++] = c;
                    estado = 80; //Notação científica
                } else {
                    devolver_char(arquivo, c);
                    lexema[i] = '\0';
                    token.tipo = T_NUM_INT;
                    strcpy(token.atributo, lexema);
                    return token;
                }
                break;

            case 78: //Float
                if (isdigit(c)) { lexema[i++] = c; estado = 79; }
                else { return (Token){T_ERRO, "Float mal formado", linha_atual, coluna_atual}; }
                break;

            case 79: //Parte fracionária
                if (isdigit(c)) { lexema[i++] = c; }
                else if (c == 'E') { lexema[i++] = c; estado = 80; }
                else {
                    devolver_char(arquivo, c);
                    lexema[i] = '\0';
                    token.tipo = T_NUM_FLOAT;
                    strcpy(token.atributo, lexema); //Atributo: valor_float
                    return token;
                }
                break;
            
            case 80: //Lê E
                if (c == '+' || c == '-') { lexema[i++] = c; estado = 81; }
                else if (isdigit(c)) { lexema[i++] = c; estado = 82; }
                else { return (Token){T_ERRO, "Expoente mal formado", linha_atual, coluna_atual}; }
                break;

            case 81: //Lê sinal do expoente
                if (isdigit(c)) { lexema[i++] = c; estado = 82; }
                else { return (Token){T_ERRO, "Expoente mal formado", linha_atual, coluna_atual}; }
                break;

            case 82: //Digitos do expoente
                if (isdigit(c)) { lexema[i++] = c; }
                else {
                    devolver_char(arquivo, c);
                    lexema[i] = '\0';
                    token.tipo = T_NUM_FLOAT;
                    strcpy(token.atributo, lexema);
                    return token;
                }
                break;

            case 85: //CHAR 
                if (c == '\\') { estado = 86; } 
                else if (c == '\'') { return (Token){T_ERRO, "Char vazio", linha_atual, coluna_atual}; }
                else { lexema[i++] = c; estado = 86; } 
                break;
            case 86:
                if (c == '\'') {
                    lexema[i] = '\0';
                    token.tipo = T_CHAR;
                    strcpy(token.atributo, lexema);
                    return token;
                } else {
                     return (Token){T_ERRO, "Char mal formado", linha_atual, coluna_atual};
                }
                break;
            
            case 92: //Seleção dos caminhos dos tokens MULT ou EXP
                if (c == '*') {
                    token.tipo = T_EXP; 
                    token.atributo[0] = '\0';
                    return token;
                } else {
                    devolver_char(arquivo, c);
                    token.tipo = T_MULT;
                    strcpy(token.atributo, "vezes");
                    return token;
                }
                break;
            // RELOP
            case 99: // <
                if (c == '=') { token.tipo = T_RELOP; strcpy(token.atributo, "LE"); return token; }
                else { devolver_char(arquivo, c); token.tipo = T_RELOP; strcpy(token.atributo, "LT"); return token; }
                break;
            case 102: // >
                if (c == '=') { token.tipo = T_RELOP; strcpy(token.atributo, "GE"); return token; }
                else { devolver_char(arquivo, c); token.tipo = T_RELOP; strcpy(token.atributo, "GT"); return token; }
                break;
            case 105: // =
                if (c == '=') { token.tipo = T_RELOP; strcpy(token.atributo, "EQ"); return token; }
                else { return (Token){T_ERRO, "= sozinho invalido (use := para atribuicao)", linha_atual, coluna_atual}; }
                break;
            case 107: // !
                if (c == '=') { token.tipo = T_RELOP; strcpy(token.atributo, "NE"); return token; }
                else { return (Token){T_ERRO, "! Sozinho invalido", linha_atual, coluna_atual}; }
                break;
            
            case 110: // ASSIGN 
                if (c == '=') { token.tipo = T_ASSIGN; return token; }
                else { return (Token){T_ERRO, ": sozinho invalido", linha_atual, coluna_atual}; }
                break;
             
            case 125: // T_COMENTARIO
                if (c == '%') { estado = 126; }
                else { return (Token){T_ERRO, "{ invalido", linha_atual, coluna_atual}; }
                break;
            case 126: 
                if (c == '%') { estado = 127; }
                else if (c == EOF) return (Token){T_EOF, "", 0, 0};
                break;
            case 127:
                if (c == '}') { 
                    estado = 0; //Não retorno token nenhum, apenas da restart e começa a leitura dos próximos tokens
                    i = 0; lexema[0] = '\0';
                }
                else if (c == '%') { estado = 127; }
                else { estado = 126; }
                break;
        }
    }
}


void imprime_token(Token t) {
    const char *nomes[] = {
        "T_EOF", "T_ERRO", 
        "T_ID", "T_MAIN", "TIPO_VOID", "TIPO_INT", "TIPO_CHAR", "TIPO_FLOAT",
        "T_IF", "T_THEN", "T_ELSIF", "T_ELSE", "T_WHILE", "T_DO", "T_FOR",
        "T_NUM_INT", "T_NUM_FLOAT", "T_CHAR",
        "T_SOMA", "T_MULT", "T_EXP", "T_RELOP", "T_ASSIGN", 
        "T_PONTOVIRG", "T_VIRG", "T_ABREPAR", "T_FECHAPAR", "T_ABRECOL", "T_FECHACOL",
        "T_COMENTARIO", "T_WS"
    };
    

    if (strlen(t.atributo) > 0)
        printf("<%s, %s>\n", nomes[t.tipo], t.atributo);
    else
        printf("<%s>\n", nomes[t.tipo]);
}