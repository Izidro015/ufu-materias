#include <stdio.h>
#include "lexico.h"
#include "sintatico.h"

//Importa o array de nomes dos tokens que já existe no sintatico.c
extern const char *nomes_tokens[];

//Função para traduzir os números dos Não-Terminais para texto (apenas para printar)
const char* obter_nome_nt(int nt) {
    switch(nt) {
        case NT_PROGRAMA: return "Programa";
        case NT_TIPORETORNO: return "TipoRetorno";
        case NT_TIPOVARIAVEL: return "TipoVariavel";
        case NT_BLOCO: return "Bloco";
        case NT_DECLVARS: return "DeclVars";
        case NT_DECLARACAO: return "Declaracao";
        case NT_LISTAIDS: return "ListaIds";
        case NT_RESTOLISTAIDS: return "RestoListaIds";
        case NT_LISTACOMANDOS: return "ListaComandos";
        case NT_COMANDO: return "Comando";
        case NT_ATRIBUICAO: return "Atribuicao";
        case NT_DECISAO: return "Decisao";
        case NT_LISTAELSIFS: return "ListaElsifs";
        case NT_OPCIONALELSE: return "OpcionalElse";
        case NT_CORPO: return "Corpo";
        case NT_REPETICAOWHILE: return "RepeticaoWhile";
        case NT_REPETICAODOWHILE: return "RepeticaoDoWhile";
        case NT_REPETICAOFOR: return "RepeticaoFor";
        case NT_CONDICAO: return "Condicao";
        case NT_EXPRESSAO: return "Expressao";
        case NT_EXPRESSAOLINHA: return "ExpressaoLinha";
        case NT_TERMO: return "Termo";
        case NT_TERMOLINHA: return "TermoLinha";
        case NT_POTENCIA: return "Potencia";
        case NT_POTENCIALINHA: return "PotenciaLinha";
        case NT_FATOR: return "Fator";
        default: return "Desconhecido";
    }
}

void imprimir_arvore(NoArvore *raiz, int nivel) {
    if (!raiz) return;
    
    for (int i = 0; i < nivel; i++) printf("  ");
    
    if (raiz->simbolo < 100) {
        //Se for menor que 100, é um Terminal (Token)
        if (raiz->token.atributo[0] != '\0') {
            printf("[%s] Atributo: %s\n", nomes_tokens[raiz->simbolo], raiz->token.atributo);
        } else {
            printf("[%s]\n", nomes_tokens[raiz->simbolo]);
        }
    } else {
        //Se for maior ou igual a 100, é um Não-Terminal
        printf("<%s>\n", obter_nome_nt(raiz->simbolo));
    }
    
    imprimir_arvore(raiz->filho, nivel + 1);
    imprimir_arvore(raiz->irmao, nivel);
}

int main() {
    FILE *arquivo = fopen("teste.txt", "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir arquivo teste.txt\n");
        return 1;
    }

    printf("Iniciando Analise Sintatica\n\n");
    
    NoArvore *arvore = analisar_sintaxe(arquivo);

    printf("\nArvore Sintatica Concreta\n");
    imprimir_arvore(arvore, 0);

    fclose(arquivo);
    return 0;
}