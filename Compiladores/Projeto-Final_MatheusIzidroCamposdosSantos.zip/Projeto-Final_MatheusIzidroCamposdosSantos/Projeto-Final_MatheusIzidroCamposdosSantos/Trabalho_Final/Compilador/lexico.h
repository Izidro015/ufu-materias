#ifndef LEXICO_H
#define LEXICO_H
#include <stdio.h>

// Definição dos Tipos de Tokens
typedef enum {
    T_EOF,          // 0 - Fim de Arquivo
    T_ERRO,         // 1
    
    // ID's
    T_ID,           // 2
    T_MAIN,         // 3
    TIPO_VOID,      // 4
    TIPO_INT,       // 5
    TIPO_CHAR,      // 6
    TIPO_FLOAT,     // 7
    
    // Comandos de Controle
    T_IF,           // 8   
    T_THEN,         // 9 
    T_ELSIF,        // 10
    T_ELSE,         // 11
    T_WHILE,        // 12
    T_DO,           // 13 
    T_FOR,          // 14
    
    //Constantes
    T_NUM_INT,      // 15
    T_NUM_FLOAT,    // 16   
    T_CHAR,         // 17        
    
    // Operadores
    T_SOMA,         // 18         
    T_MULT,         // 19        
    T_EXP,          // 20         
    T_RELOP,        // 21       
    T_ASSIGN,       // 22      
    
    // Pontuação
    T_PONTOVIRG,    // 23
    T_VIRG,         // 24
    T_ABREPAR,      // 25 
    T_FECHAPAR,     // 26
    T_ABRECOL,      // 27 
    T_FECHACOL,     // 28
    
    // Comentário e WS que serão ignorados
    T_COMENTARIO,   // 29    
    T_WS            // 30
} TokenType;

typedef struct {
    TokenType tipo;
    char atributo[50]; 
    int linha;
    int coluna;
} Token;

//Para controle e em caso de retornar erro sintatico e quando for semantico pega os de token
extern int linha_atual;
extern int coluna_atual;

Token proximo_token(FILE *arquivo);
void imprime_token(Token t);

#endif