#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "exp.h"

extern FILE *yyin;
extern int yylex(void);
extern int linha;

int main(int argc, char **argv) {
    char nome_arquivo[256];
    
    if (argc < 2) {
        printf("Digite o nome do arquivo: ");
        if (fgets(nome_arquivo, sizeof(nome_arquivo), stdin) == NULL) {
            fprintf(stderr, "Erro ao ler nome do arq\n");
            return 1;
        }
        
        size_t len = strlen(nome_arquivo);
        if (len > 0 && nome_arquivo[len-1] == '\n') {
            nome_arquivo[len-1] = '\0';
        }
    } else {
        strcpy(nome_arquivo, argv[1]);
    }
    
    FILE *arquivo = fopen(nome_arquivo, "r");
    if (!arquivo) {
        fprintf(stderr, "Erro ao abrir o arquivo\n");
        fprintf(stderr, "Verifique se o arquivo existe ou se o caminho esta correto\n");
        return 1;
    }
    
    yyin = arquivo;
    
    printf("\nLista do: %s \n\n", nome_arquivo);
    
    int token;
    int total_tokens = 0;
    
    while((token = yylex()) != ENDFILE) {
        if (token != ERROR) { // Conta apenas tokens válidos
            total_tokens++;
        }
    }
    
    printf("\nFim\n");
    printf("Total de linhas: %d\n", linha);
    printf("Total de tokens: %d\n", total_tokens);
    
    fclose(arquivo);
    
    return 0;
}