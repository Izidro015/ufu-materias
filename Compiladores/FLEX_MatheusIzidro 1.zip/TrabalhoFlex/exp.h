#ifndef EXP_H
#define EXP_H

#include <stdio.h>

#define TRUE 1
#define FALSE 0

typedef enum {
    IF, THEN, ELSE, END, REPEAT, UNTIL, READ, WRITE, WHILE,ATRIB, RELOP, PLUS, MINUS, 
    TIMES, DIVIDE, LPAREN, RPAREN, SEMI, ID, NUM_INT, NUM_FLOAT,ERROR, ENDFILE
} TokenType;
//ERROR = erro lexico
extern int lineno;

#endif