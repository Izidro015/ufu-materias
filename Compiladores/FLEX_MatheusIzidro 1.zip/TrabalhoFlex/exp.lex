%{
#include <stdio.h>
#include <stdlib.h>
#include "exp.h"

int linha = 1;
%}

%%

"if"        { printf("Token: IF, Lexema: %s, Linha: %d\n", yytext, linha); return IF; }
"then"      { printf("Token: THEN, Lexema: %s, Linha: %d\n", yytext, linha); return THEN; }
"else"      { printf("Token: ELSE, Lexema: %s, Linha: %d\n", yytext, linha); return ELSE; }
"end"       { printf("Token: END, Lexema: %s, Linha: %d\n", yytext, linha); return END; }
"while"     { printf("Token: WHILE, Lexema: %s, Linha: %d\n", yytext, linha); return WHILE; }
"repeat"    { printf("Token: REPEAT, Lexema: %s, Linha: %d\n", yytext, linha); return REPEAT; }
"until"     { printf("Token: UNTIL, Lexema: %s, Linha: %d\n", yytext, linha); return UNTIL; }
"read"      { printf("Token: READ, Lexema: %s, Linha: %d\n", yytext, linha); return READ; }
"write"     { printf("Token: WRITE, Lexema: %s, Linha: %d\n", yytext, linha); return WRITE; }

":="        { printf("Token: ATRIB, Lexema: %s, Linha: %d\n", yytext, linha); return ATRIB; }

"<"|">"|"<="|">="|"=="|"!="  { printf("Token: RELOP, Lexema: %s, Linha: %d\n", yytext, linha); return RELOP; }

"+"         { printf("Token: PLUS, Lexema: %s, Linha: %d\n", yytext, linha); return PLUS; }
"-"         { printf("Token: MINUS, Lexema: %s, Linha: %d\n", yytext, linha); return MINUS; }
"*"         { printf("Token: TIMES, Lexema: %s, Linha: %d\n", yytext, linha); return TIMES; }
"/"         { printf("Token: DIVIDE, Lexema: %s, Linha: %d\n", yytext, linha); return DIVIDE; }

"("         { printf("Token: LPAREN, Lexema: %s, Linha: %d\n", yytext, linha); return LPAREN; }
")"         { printf("Token: RPAREN, Lexema: %s, Linha: %d\n", yytext, linha); return RPAREN; }
";"         { printf("Token: SEMI, Lexema: %s, Linha: %d\n", yytext, linha); return SEMI; }

[0-9]+\.[0-9]+([eE][+-]?[0-9]+)? { printf("Token: NUM_FLOAT, Lexema: %s, Linha: %d\n", yytext, linha); return NUM_FLOAT; }
[0-9]+      { printf("Token: NUM_INT, Lexema: %s, Linha: %d\n", yytext, linha); return NUM_INT; }
[a-zA-Z][a-zA-Z0-9_]* { printf("Token: ID, Lexema: %s, Linha: %d\n", yytext, linha); return ID; }

[ \t]+      { /* ignora espacos */ }
\n          { linha++; }

.           { printf("Caractere nao reconhecido: '%c', Linha: %d\n", yytext[0], linha); return ERROR; }

<<EOF>>     { return ENDFILE; }

%%

int yywrap() {
    return 1;
}